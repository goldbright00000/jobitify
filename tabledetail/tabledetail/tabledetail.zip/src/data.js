//Json data
export const Data = [
    {
        data: {
            ev_1: {
                par: {
                    1: {
                        "name": "Tottenham",
                        "res": 0
                    },
                    2: {
                        "name": "Chelsea",
                        "res": 3
                    }
                },
                stage: {
                    name: "England Premier League"
                },
                status: "Finished",
                status_id: 99,
                start_date: "2021-09-19 18:30"
            },
            ev_2: {
                par: {
                    1: {
                        "name": "West Ham",
                        "res": 1
                    },
                    2: {
                        "name": "Manchester United",
                        "res": 2
                    }
                },
                stage: {
                    name: "England Premier League"
                },
                status: "Finished",
                status_id: 99,
                start_date: "2021-09-19 16:00"
            },
            ev_3: {
                par: {
                    1: {
                        name: "Brighton",
                        res: 2
                    },
                    2: {
                        name: "Leicester",
                        res: 1
                    }
                },
                stage: {
                    name: "England Premier League"
                },
                status: "Finished",
                status_id: 99,
                start_date: "2021-09-19 16:00"
            }
        }
    }
]