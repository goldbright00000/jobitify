import './App.css';

// components
import Table from './components/Table';

function App() {
  return (
    <div>
        <Table/>
    </div>
  );
}

export default App;
